package com.careerforge.backend.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.careerforge.backend.entity.Application;

public interface ApplicationRepository
        extends JpaRepository<Application, Long> {

    Optional<Application> findByProfileIdAndJobId(
            Long profileId,
            Long jobId
    );
}